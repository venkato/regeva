Less v332

  This version of less has been compiled under Windows NT, and should
 work okay with both Windows 95 and Windows NT.

  If you wish to build the binaries yourself, and have Visual C++ installed
 then change to the previous "Less-322" directory and type "nmake".  For
 other compilers, and more information please see the README, and the INSTALL
 files in that directory.

Steve Kemp
---
  http://www.tardis.ed.ac.uk/~skx
  skx@tardis.ed.ac.uk

